colcon-metadata
===============

An extension for `colcon-core <https://github.com/colcon/colcon-core>`_ to fetch and manage package metadata from repositories.

For an example repository containing metadata see `colcon-metadata-repository <https://github.com/colcon/colcon-metadata-repository>`_.
