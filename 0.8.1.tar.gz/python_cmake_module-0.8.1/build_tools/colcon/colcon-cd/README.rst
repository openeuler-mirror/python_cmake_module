colcon-cd
=========

A shell function for `colcon-core <https://github.com/colcon/colcon-core>`_ to change the current working directory.

See the `documentation <https://colcon.readthedocs.io/en/released/user/installation.html#quick-directory-changes>`_ on how to use it.
