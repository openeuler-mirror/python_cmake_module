Example test scripts
=====================


The files in this folder are not direct tests, but rather example test suites that demonstrate certain issues/behaviours.

In the future we will move part of the content of the acceptance tests here in order to have directly testable code instead of writing out things and then running them in nested pytest sessions/subprocesses.

This will aid debugging and comprehension.
