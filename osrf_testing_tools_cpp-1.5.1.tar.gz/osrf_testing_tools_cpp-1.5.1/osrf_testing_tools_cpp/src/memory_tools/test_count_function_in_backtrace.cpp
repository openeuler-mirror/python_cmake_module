void func();

int main(void)
{
  func();
  return 0;
}
