^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package test_osrf_testing_tools_cpp
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.5.1 (2022-02-14)
------------------

1.5.0 (2022-01-14)
------------------
* remove explicit use of -Werror (`#67 <https://github.com/osrf/osrf_testing_tools_cpp/issues/67>`_)
* Contributors: William Woodall

1.4.0 (2020-12-08)
------------------

1.3.2 (2020-05-21)
------------------
